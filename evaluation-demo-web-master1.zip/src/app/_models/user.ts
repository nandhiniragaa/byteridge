﻿export class User
{
    id: number;
    username: string;
    password: string;
    role: string;
    firstName: string;
    lastName: string;
    token: string;
}